##Filter

> 过滤器 ， 其实就是对客户端发出来的请求进行过滤。 浏览器发出， 然后服务器派servlet处理。  在中间就可以过滤， 其实过滤器起到的是拦截的作用。

* 作用
	
	1. 对一些敏感词汇进行过滤
	2. 统一设置编码
	3. 自动登录
	
	...

###如何使用Filter

1. 定义一个类， 实现Filter

		public class FilterDemo implements Filter {

			public void destroy() {
			}
		
			public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
				System.out.println("来到过虑器了。。。");
				chain.doFilter(request, response);
			}
		
			public void init(FilterConfig fConfig) throws ServletException {
			}
		
		}

2. 注册过滤器

> 在web.xml里面注册，注册的手法与servlet基本一样。


		  	<filter>
		    <display-name>FilterDemo</display-name>
		    <filter-name>FilterDemo</filter-name>
		    <filter-class>com.itheima.filter.FilterDemo</filter-class>
		  </filter>
		  <filter-mapping>
		    <filter-name>FilterDemo</filter-name>
		    <url-pattern>/*</url-pattern>
		  </filter-mapping>


###Filter的生命周期

* 创建

> 在服务器启动的时候就创建。 

* 销毁

> 服务器停止的时候。


###Filter执行顺序

1. 客户端发出请求，先经过过滤器， 如果过滤器放行，那么才能到servlet

2. 如果有多个过滤器， 那么他们会按照注册的映射顺序 来 排队。 只要有一个过滤器， 不放行，那么后面排队的过滤器以及咱们的servlet都不会收到请求。


##Filter细节：

1. init方法的参数 FilterConfig , 可以用于获取filter在注册的名字 以及初始化参数。  其实这里的设计的初衷与ServletConfig是一样的。

2. 如果想放行，那么在doFilter 方法里面操作，使用参数 chain


		chain.doFilter(request, response); 放行， 让请求到达下一个目标。

3.  <url-pattern>/*</url-pattern> 写法格式与servlet一样。

	1. 全路径匹配  以 /  开始 

			/LoginServlet

	2. 以目录匹配 以 / 开始  以 * 结束

		/demo01/*  

	3. 以后缀名匹配  以 * 开始 以后缀名结束

		*.jsp  *.html *.do 

4. 针对 dispatcher 设置

		REQUEST ： 只要是请求过来，都拦截，默认就是REQUEST 
		FORWARD : 只要是转发都拦截。 
		ERROR ： 页面出错发生跳转 
		INCLUDE ： 包含页面的时候就拦截。

###自动登录

* 需求分析

![icon](img/img05.png)
			

####1. 搭建环境

1. 搭建数据库

2. 搭建页面


###登录servlet代码


		protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		try {
			String userName = request.getParameter("username");
			String password = request.getParameter("password");
			String autoLogin = request.getParameter("auto_login");
			UserBean user = new UserBean();
			user.setUsername(userName);
			user.setPassword(password);
			
			UserDao dao = new UserDaoImpl();
			UserBean userBean = dao.login(user);
			
			if(userBean != null){
				//成功了，进入首页
				request.getSession().setAttribute("userBean", userBean);
				response.sendRedirect("index.jsp");
			}else{
				//不成功...
				request.getRequestDispatcher("login.jsp").forward(request, response);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}


##过滤器代码

>  过滤器的核心不是完成拦截不给 ， 还是放行显示。 它的核心是在放行之前，帮用户完成登录的功能。 

* 实现思路

1. 先判断session是否有效， 如果有效，就不用取cookie了，直接放行。

2. 如果session失效了，那么就取 cookie。

	1. 没有cookie  放行 

	2. 有cookie 

			1. 取出来cookie的值，然后完成登录
			2. 把这个用户的值存储到session中

			3. 放行。


##index.jsp代码


			<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
				<body>
				这是首页，
				<c:if test="${not empty userBean }">
				欢迎您${userBean.username }
				</c:if>
				<c:if test="${empty userBean }">
				您好，请登录！！！
				</c:if>
			</body>

##login.jsp代码：
		<body>
	<form action="LoginServlet" method="post">
		账号：<input type="text" name="username"><br> 
		密码：<input type="password" name="password"><br> 
		<input type="checkbox" name="auto_login">自动登录<br> 
		<input type="submit" value="登录">
	</form>
	</body>	
##UserBean代码：
	public class UserBean {
		private int id;
		private String username;
		private String password;
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getUsername() {
			return username;
		}
		public void setUsername(String username) {
			this.username = username;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		
	}

##UserDao代码：
			public interface UserDao {
	/**
	 * 执行登录，并返回该用户的所有信息。
	 * @param user 执行登陆的用户信息
	 * 
	 * */
		UserBean login(UserBean user)throws SQLException;
	}
##UserDaoImpl代码：
public class UserDaoImpl implements UserDao {

	public UserBean login(UserBean user) throws SQLException {
		QueryRunner runner = new QueryRunner(JDBCTUtil02.getDataSource());
		String sql ="select * from t_user where username =? and password = ?";
		return runner.query(sql, new BeanHandler<UserBean>(UserBean.class),user.getUsername(),user.getPassword());
		
	}

}

##LoginServlet代码：
		public class LoginServlet extends HttpServlet {
	
		protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			try {
			
			String userName = request.getParameter("username");
			String password = request.getParameter("password");
			String autoLogin = request.getParameter("auto_login");
			
			
			UserBean user = new UserBean();
			user.setUsername(userName);
			user.setPassword(password);
			
			UserDao dao = new UserDaoImpl();
				
			UserBean userBean = dao.login(user);
			if(userBean != null){
				if("on".equals(autoLogin)){
					//发送cookie给客户端
					Cookie cookie = new Cookie("ayto_login",userName+"#"+password);
					cookie.setMaxAge(60*60*24*7);
					cookie.setPath("/AutoLoginDemo");
					cookie.setPath(request.getContextPath());//得到的就是“/”+项目名
	//				System.out.println(request.getContextPath());
					response.addCookie(cookie);
				}
				
				//如果成功，跳转到首页
				request.getSession().setAttribute("userBean", userBean);
				response.sendRedirect("index.jsp");
			}else{
				//如果不成功，还返回到这个界面
				request.getRequestDispatcher("login.jsp").forward(request, response);
			}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
	//		System.out.println(userName+" = "+password+"..."+autoLogin);
		}
	
	
		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			doGet(request, response);
		}
	
	}
##过滤器代码

>  过滤器的核心不是完成拦截不给 ， 还是放行显示。 它的核心是在放行之前，帮用户完成登录的功能。 

* 实现思路

1. 先判断session是否有效， 如果有效，就不用取cookie了，直接放行。

2. 如果session失效了，那么就取 cookie。

	1. 没有cookie  放行 

	2. 有cookie 

			1. 取出来cookie的值，然后完成登录
			2. 把这个用户的值存储到session中

			3. 放行。


			public class AutoLoginFilter implements Filter {
		
		
			public void destroy() {
				
			}

	
			public void doFilter(ServletRequest req, ServletResponse response, FilterChain chain) throws IOException, ServletException {
				
				HttpServletRequest request = (HttpServletRequest) req;
				
				try {
					UserBean userBean = (UserBean) request.getSession().getAttribute("userBean");
		
					if(userBean != null){
						
						chain.doFilter(request, response);
		
					}else{
						//代表session失效了。
						//2.看cookie
						//1.来请求的时候，先从请求里面取出cookie
						Cookie[] cookies = request.getCookies();
						//2.从一堆cookie里面找出我们以前给浏览器发的那个cookie
						Cookie cookie = CookieUtil.findCookid(cookies, "auto_login");
						if(cookie == null){
							chain.doFilter(request, response);		
						}else{
							//不是第一次。
							String value = cookie.getValue();
							String username = value.split("#")[0];
							String password = value.split("#")[1];
							
							UserBean user = new UserBean();
							user.setPassword(password);
							user.setUsername(username);
							
							UserDao dao = new UserDaoImpl();
							userBean = dao.login(user);
							
							//使用session存这个值到域中，方便下一次存
							request.getSession().setAttribute("userBean", userBean);
		
							chain.doFilter(request, response);		
								
						}
					}
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						
						chain.doFilter(request, response);		
		
					}
				}	
		
			public void init(FilterConfig fConfig) throws ServletException {
		
			}
		
			}
##CookieUtil代码：
	public class CookieUtil {
	public static Cookie findCookid(Cookie[] cookies,String name){
		if(cookies != null){
			for (Cookie cookie : cookies) {
				if(name.equals(cookie.getName())){
					return cookie;
				}
			}
		}
		
		
		return null;
	}
	}

------------

###BeanUtils的使用

> BeanUtils.populate(bean, map);	

			//注册自己的日期转换器
			ConvertUtils.register(new MyDateConverter(), Date.class);
			
			
			//转化数据
			Map map = request.getParameterMap();
			UserBean bean = new UserBean();

			转化map中的数据，放置到bean对象身上
			BeanUtils.populate(bean, map);	



#总结

##Listener

	8个 

	三种类型  
		针对三个作用域的创建和销毁
		针对三个作用域的值改变 【添加 | 替换 | 移除】
		针对session中的值 【钝化 活化】 ， 【绑定  解绑】

	钝化 ( 序列化 ) 
		内存中的对象存储到硬盘 

		超时失效。 session销毁了。 
	
	非正常关闭服务器， 钝化  。 正常关闭服务器 销毁

	设置了session，多久时间。 context.xml
	

	活化 (反序列化)
		从硬盘里面读取到内存


ServletContextListner  ： 应用被部署的时候， 服务器加载这个项目的时候，做一些初始化工作， 任务调度。
HttpSessionListener	： 统计在线人数
HttpSessionActivationListener  ： 钝化活化处理


	


	
##Filter 

> 使用频率更高

* 如果要写一个过滤器。

> 1. 定义一个类，实现接口 Filter

> 2. 注册 . web.xml . 与servlet相似。

* 过滤器放行。 

> chain.doFilter(request, response);

* 过滤器生命周期

	创建： 服务器加载这个项目的时候创建实例
 
	销毁： 关闭服务器或者从服务器中移除项目的时候。