* 监听器的内部机制

> 其实就是接口回调. 


####接口回调

* 需求：

> A在执行循环，当循环到5的时候， 通知B。

> 事先先把一个对象传递给 A ， 当A 执行到5的时候，通过这个对象，来调用B中的方法。 但是注意，不是直接传递B的实例，而是传递一个接口的实例过去。

![icon](img/img01.png)
###Web监听器

> 总共有8个 划分成三种类型

1. 定义一个类，实现接口

2. 注册 | 配置监听器


### 监听三个作用域创建和销毁

 	request  ---httpServletRequest
	session  ---httpSession
	aapplication  --- ServletContext

	1. ServletContextListener

		servletcontext创建：

			1. 启动服务器的时候

		servletContext销毁：

			2. 关闭服务器. 从服务器移除项目
			

	2. ServletRequestListener

		request创建:

			访问服务器上的任意资源都会有请求出现。

			访问 html： 会
			访问 jsp:	会
			访问 servlet : 会 
			

		request销毁：

			服务器已经对这次请求作出了响应。


			public class MyRequestListener implements ServletRequestListener {
					@Override
					public void requestDestroyed(ServletRequestEvent sre) {
						System.out.println("servletrequest 销毁了");
					}
				
					@Override
					public void requestInitialized(ServletRequestEvent sre) {
						System.out.println("servletrequest 初始化了");
					}
				}

			  
			  <listener>
			  <listener-class>
				top.miaodou.listener.MyRequestListener
				</listener-class>
			  </listener>

3. HttpSessionListener

		session的创建
			只要调用getSession

			html:		不会
			jsp:		会	  getSession();
			servlet: 	会

		session的销毁
			超时  30分钟
			
			非正常关闭 销毁

			正常关闭服务器(序列化)

			public class MySessionListener implements HttpSessionListener {

				@Override
				public void sessionCreated(HttpSessionEvent se) {
					System.out.println("创建session了");
				}
			
				@Override
				public void sessionDestroyed(HttpSessionEvent se) {
					System.out.println("销毁session了");
				}
			}

作用：
	
	ServletContextListener

		利用它来，在servletcontext创建的时候， 
			1. 完成自己想要的初始化工作

			2. 执行自定义任务调度。 执行某一个任务。 Timer  

	HttpSessionListener

		统计在线人数.

### 监听三个作用域属性状态变更


> 可以监听在作用域中值 添加  | 替换  | 移除的动作。 

* servletContext --- ServletContextAttributeListener
![icon](img/img03.png)

* request --- ServletRequestAttributeListener
![icon](img/img04.png)

* session --- HttpSessionAttributeListener
![icon](img/img02.png)


* HttpSessionActivationListener


		<%
		Bean01 bean = new Bean01();
		bean.setName("zhangsan");
		
		session.setAttribute("bean",bean);
		session.removeAttribute("bean");
		%>
			private String name;

		public String getName() {
			return name;
		}
	
		public void setName(String name) {
			this.name = name;
		}
	
		public void valueBound(HttpSessionBindingEvent arg0) {
			System.out.println("值被绑定进来了");
		}
	
		public void valueUnbound(HttpSessionBindingEvent arg0) {
			System.out.println("值被解除绑定");
		}
* HttpSessionActivationListener

> 用于监听现在session的值 是 钝化 （序列化）还是活化 （反序列化）的动作

* 钝化 （序列化） 

> 把内存中的数据 存储到硬盘上

* 活化 （反序列化）

> 把硬盘中的数据读取到内存中。


* session的钝化活化的用意何在

>  session中的值可能会很多， 并且我们有很长一段时间不使用这个内存中的值， 那么可以考虑把session的值可以存储到硬盘上【钝化】，等下一次在使用的时候，在从硬盘上提取出来。 【活化】

* 如何让session的在一定时间内钝化. 

> 做配置即可

	1. 在tomcat里面 conf/context.xml 里面配置

			对所有的运行在这个服务器的项目生效  

	2. 在conf/Catalina/localhost/context.xml 配置

			对 localhost生效。  localhost:8080

	3. 在自己的web工程项目中的 META-INF/context.xml

			只对当前的工程生效。

		maxIdleSwap ： 1分钟不用就钝化
		directory ：  钝化后的那个文件存放的目录位置。 

			D:\tomcat\apache-tomcat-7.0.52\work\Catalina\localhost\ListenerDemo\itheima

		<Context>
			<Manager className="org.apache.catalina.session.PersistentManager" maxIdleSwap="1">
				<Store className="org.apache.catalina.session.FileStore" directory="itheima"/>
			</Manager>
		</Context>

##代码实现
##MyHttpSessionListener03.class代码
		public class MyHttpSessionListener03 implements HttpSessionActivationListener {
	
		//钝化
		public void sessionWillPassivate(HttpSessionEvent arg0) {
			System.out.println("session被钝化了。。。。");
		}
		//活化
		public void sessionDidActivate(HttpSessionEvent arg0) {
			System.out.println("session被活化了。。。。");
		}
	}
##Bean02.java代码
	public class Bean02 implements HttpSessionActivationListener,Serializable{
	private String name;
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void sessionWillPassivate(HttpSessionEvent se) {
		System.out.println("session被钝化了。。。。");
	}
	public void sessionDidActivate(HttpSessionEvent se) {
		System.out.println("session被活化了。。。。");
	}
	}
	demo04.jsp
	<body>
##这是demo04页面，
	
	<%
		Bean02 bean = new Bean02();
		bean.setName("lisisi");
		session.setAttribute("bean", bean);
	%>
	</body>
##这是demo05页面，
				<body>	
					这是demo05页面
					${bean.name }
				</body>
##这是META-INF/context.xml代码
		<Context>
			<Manager className="org.apache.catalina.session.PersistentManager"
				maxIdleSwap="1">
				<Store className="org.apache.catalina.session.FileStore"
					directory="itheima" />
			</Manager>
		</Context>